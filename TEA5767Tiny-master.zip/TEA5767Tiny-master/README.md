TEA5767Tiny
===========

Adopted version of the TEA5767 library to work on Attiny microcontrollers